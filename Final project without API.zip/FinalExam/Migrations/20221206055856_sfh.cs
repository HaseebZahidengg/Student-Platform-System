﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace FinalExam.Migrations
{
    public partial class sfh : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "date",
                table: "Posts",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "dislikes",
                table: "Posts",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "likes",
                table: "Posts",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "date",
                table: "Posts");

            migrationBuilder.DropColumn(
                name: "dislikes",
                table: "Posts");

            migrationBuilder.DropColumn(
                name: "likes",
                table: "Posts");
        }
    }
}
