﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalExam.Data;
using Microsoft.AspNetCore.Mvc;
using FinalExam.Models;
using Microsoft.AspNetCore.Http;


namespace FinalExam.Controllers
{
    public class PostController : Controller
    {
        private readonly ProjectDBContext dbcontext;
        public PostController(ProjectDBContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }
        public IActionResult Index()
        {
            List<Posts> result1 = dbcontext.Posts.OrderByDescending(e=>e.likes).ThenByDescending(e=>e.date).ToList();
            List<Comments> result2 = dbcontext.Comments.ToList();
            List<Votes> result3 = dbcontext.Votes.ToList();
            PostArchieve result = new PostArchieve();
            result.AllPosts = result1;
            result.AllComments = result2;
            result.AllVotes = result3;
            return View(result);
        }

        public IActionResult CreatePost()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreatePost(Posts obj)
        {
            if (ModelState.IsValid)
            {
                var tempPost = new Posts
                {
                    authorName = obj.authorName,
                    authorID = obj.authorID,
                    postTitile = obj.postTitile,
                    postBody = obj.postBody,
                    date = DateTime.Now
                };
                dbcontext.Posts.Add(tempPost);
                dbcontext.SaveChanges();
                return RedirectToAction("Index", "Post");

            }
            else
            {
                TempData["posterror"] = "Something went wrong";
                return View();
            }
        }


        //Added in the Exam part 2
        public IActionResult EditPost(int id)
        {
            
            var tempPost = dbcontext.Posts.SingleOrDefault(e => e.Id == id);
            if (HttpContext.Session.GetString("UserID") == tempPost.authorID.ToString())
            {
                var result = new Posts()
                {
                    Id = tempPost.Id,
                    postTitile = tempPost.postTitile,
                    postBody = tempPost.postBody,
                    authorID = tempPost.authorID
                };
                return View(result);
            }

            else
            {
                return RedirectToAction("Permission", "Home");
            }
        }
        [HttpPost]
        public IActionResult EditPost(Posts obj)
        {
            dbcontext.Posts.Update(obj);
            dbcontext.SaveChanges();
            return RedirectToAction("Index", "Post");
        }


        public IActionResult DeletePost( int id)
        {
            var tempPost = dbcontext.Posts.SingleOrDefault(e => e.Id == id);
            if (HttpContext.Session.GetString("UserID") == tempPost.authorID.ToString())
            {
                dbcontext.Remove(tempPost);
                dbcontext.SaveChanges();
                return RedirectToAction("Index", "Post");
            }

            else
            {
                return RedirectToAction("Permission", "Home");
            }
        }



        //Comments Handler section
        [HttpPost]
        public IActionResult AddComment(Comments obj)
        {
            dbcontext.Comments.Add(obj);
            dbcontext.SaveChanges();
            return RedirectToAction("Index", "Post");
        }

        public IActionResult DeleteComment(int id)
        {
            var tempCmt = dbcontext.Comments.SingleOrDefault(e => e.Id == id);
            dbcontext.Comments.Remove(tempCmt);
            dbcontext.SaveChanges();
            return RedirectToAction("Index", "Post");
        }

        public IActionResult EditComt(int id)
        {
            var tempCmt = dbcontext.Comments.SingleOrDefault(e => e.Id == id);
            return View(tempCmt);
        }
        [HttpPost]
        public IActionResult EditComt(Comments obj)
        {
            dbcontext.Comments.Update(obj);
            dbcontext.SaveChanges();
            return RedirectToAction("Index", "Post");
        }


        //To handle voting
        public ActionResult postCount()
        {
            var tempID = (int)TempData["PostIDToAddVote"];
            var tempPost = dbcontext.Posts.SingleOrDefault(e => e.Id == tempID);
            var result = new Posts()
            {
                Id = tempPost.Id,
                postTitile = tempPost.postTitile,
                postBody = tempPost.postBody,
                authorID = tempPost.authorID,
                authorName = tempPost.authorName,
            };
            if ((bool)TempData["VoteStatus"] == true)
            {
                result.likes = (tempPost.likes) + 1;
            }
            if ((bool)TempData["VoteStatus"] == false)
            {
                result.dislikes = (tempPost.dislikes) + 1;
            }
            dbcontext.Posts.Update(result);
            dbcontext.SaveChanges();
            return RedirectToAction("Index", "Post");
        }

        public IActionResult upvote(Votes obj)
        {
            TempData["PostIDToAddVote"] = obj.postID;
            TempData["VoteStatus"] = obj.status;
            dbcontext.Votes.Add(obj);
            dbcontext.SaveChanges();
            return RedirectToAction("postCount", "Post");
        }

        public IActionResult changeVoteTolike(Votes obj)
        {
            var result = dbcontext.Votes.SingleOrDefault(e => e.Id == obj.Id);
            if (result.status == false)
            {
                var tempPost = dbcontext.Posts.SingleOrDefault(e => e.Id == obj.postID);
                var holdPost = new Posts
                {
                    Id = tempPost.Id,
                    postTitile = tempPost.postTitile,
                    postBody = tempPost.postBody,
                    authorID = tempPost.authorID,
                    authorName = tempPost.authorName,
                    date =tempPost.date
                };
                holdPost.likes = (tempPost.likes) + 1;
                if (tempPost.dislikes == 0)
                {
                    holdPost.dislikes = 0;
                }
                else
                {
                    holdPost.dislikes = (tempPost.dislikes) - 1;
                }
                var holdvote = new Votes
                {
                    Id = obj.Id,
                    Users = obj.Users,
                    Posts = obj.Posts,
                    postID = obj.postID,
                    userID = obj.userID,
                    status = obj.status
                };

                dbcontext.Posts.Update(holdPost);
                dbcontext.SaveChanges();
                dbcontext.Votes.Update(holdvote);
                dbcontext.SaveChanges();


                return RedirectToAction("Index", "Post");
            }

            return RedirectToAction("Index", "Post");

        }



        public IActionResult changeVoteTodislike(Votes obj)
        {

            var tempPost = dbcontext.Posts.SingleOrDefault(e => e.Id == obj.postID);
            var holdPost = new Posts
            {
                Id = tempPost.Id,
                postTitile = tempPost.postTitile,
                postBody = tempPost.postBody,
                authorID = tempPost.authorID,
                authorName = tempPost.authorName,
                date = tempPost.date
            };
            holdPost.dislikes = (tempPost.dislikes) + 1;
            if (tempPost.likes == 0)
            {
                holdPost.likes = 0;
            }
            else
            {
                holdPost.likes = (tempPost.likes) - 1;
            }
            
            var holdvote = new Votes
            {
                Id = obj.Id,
                Users = obj.Users,
                Posts = obj.Posts,
                postID = obj.postID,
                userID = obj.userID,
                status = obj.status
            };

            dbcontext.Posts.Update(holdPost);
            dbcontext.SaveChanges();
            dbcontext.Votes.Update(holdvote);
            dbcontext.SaveChanges();


            return RedirectToAction("Index", "Post");
        }



    }
}