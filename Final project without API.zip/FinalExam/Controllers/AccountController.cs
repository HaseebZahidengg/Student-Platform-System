﻿using System.Linq;
using System.Security.Claims;
using FinalExam.Data;
using FinalExam.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace FinalExam.Controllers
{
    public class AccountController : Controller
    {
        private readonly ProjectDBContext dbcontext;
        public AccountController(ProjectDBContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login()
        {
            if (User.Identity.IsAuthenticated)
            {
                return RedirectToAction("Index", "Post");
            }
            else
            {
                return View();
            }
        }


        [HttpPost]
        public IActionResult Login(LoginDetails obj)
        {
            if (ModelState.IsValid)
            {
                var data = dbcontext.Users.Where(e => e.username == obj.username).SingleOrDefault();
                if(data != null)
                {
                    //bool isValid = (data.username==obj.username && data.password==obj.password);
                    if (data.password == obj.password)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, obj.username) }, CookieAuthenticationDefaults.AuthenticationScheme);
                        var principal = new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                        HttpContext.Session.SetString("Username", obj.username);
                        HttpContext.Session.SetString("UserID", data.Id.ToString());
                        TempData["CurrentUserID"] = data.Id;

                        if (data.isSuperUser)
                        {
                            HttpContext.Session.SetString("UserType", "SuperAdmin");
                            return RedirectToAction("Index", "Instructor");
                        }
                        if (data.isInstructor)
                        {
                            HttpContext.Session.SetString("UserType", "Instructor");
                            return RedirectToAction("Index", "Post");
                        }
                        if (data.isStudent)
                        {
                            HttpContext.Session.SetString("UserType", "Student");
                            return RedirectToAction("Index", "Post");

                        }
                    }
                    else
                    {
                        TempData["errorMessage"] = "Incorrect password";
                    }
                }
                else
                {
                    TempData["errorMessage"] = "Username not found";
                }
            }
            else
            {
                TempData["errorMessage"] = "Please fill all the feilds";
                //return RedirectToAction("Login", "Account");
            }
            return RedirectToAction("Login", "Account");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }


        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(Users obj)
        {
            if (ModelState.IsValid)
            {
                var temp = new Users()
                {
                    firstName = obj.firstName,
                    lastName = obj.lastName,
                    username = obj.username,
                    password = obj.password,
                    isStudent = obj.isStudent
                };
                try
                {
                    dbcontext.Users.Add(temp);
                    dbcontext.SaveChanges();
                    return RedirectToAction("Login", "Account");

                }
                catch
                {
                    TempData["duplicateUsername"] = "Username already exist";
                    return View();

                }

            }
            else
            {
                TempData["Register Error"] = "Please fill all the feilds before submission";
                return View();
            }
        }
    }
}
