﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalExam.Data;
using FinalExam.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace FinalExam.Controllers
{

    public class InstructorController : Controller
    {
        private readonly ProjectDBContext dbcontext;    
        public InstructorController(ProjectDBContext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        public IActionResult Index()
        {
            var result = dbcontext.Users.Where(e=>e.isInstructor == true).ToList();
            return View(result);
        }

        //By default it's Get Method
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create( Users obj)
        {
            if (ModelState.IsValid)
            {
                var temp = new Users()
                {
                    firstName = obj.firstName,
                    lastName = obj.lastName,
                    username = obj.username,
                    password = obj.password,
                    isInstructor = obj.isInstructor
                };
                try
                {
                    dbcontext.Users.Add(temp);
                    dbcontext.SaveChanges();
                    return RedirectToAction("Index", "Instructor");
                }
                catch
                {
                    TempData["duplicateUsername"] = "Username already exist";
                    return View();
                }

            }

            else
            {
                TempData["error"] = "Empty feilds can't be submitted";
                return View();
            }
        }

        public IActionResult Delete(int id)
        {
            var inc = dbcontext.Users.SingleOrDefault(e => e.Id == id);
            dbcontext.Remove(inc);
            dbcontext.SaveChanges();
            return RedirectToAction("Index");
        }
        
        public IActionResult Edit( int id)
        {
            var inc = dbcontext.Users.SingleOrDefault(e => e.Id == id);
            var result = new Users()
            {
                firstName = inc.firstName,
                lastName = inc.lastName,
                username = inc.username,
                password = inc.password,
                isInstructor = inc.isInstructor
                
            };
            return View(result);
        }

        
        [HttpPost]
        public IActionResult Edit(Users model)
        {
            var inc = new Users()
            {
                Id = model.Id,
                firstName = model.firstName,
                lastName = model.lastName,
                username = model.username,
                password = model.password,
                isInstructor = model.isInstructor
            };

            try
            {
                dbcontext.Users.Update(inc);
                dbcontext.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                TempData["duplicateUsername"] = "Username already exist";
                return View();
            }
        }

    }
}