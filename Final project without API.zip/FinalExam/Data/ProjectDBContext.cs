﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalExam.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalExam.Data
{
    public class ProjectDBContext : DbContext
    {
        public ProjectDBContext (DbContextOptions<ProjectDBContext>options): base(options) { }
        public DbSet<Users> Users { get; set; }
        public DbSet<Posts> Posts { get; set; }
        public DbSet<Comments> Comments { get; set; }
        public DbSet<Votes> Votes { get; set; }
    }

}
