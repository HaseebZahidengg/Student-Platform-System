﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace FinalExam.Models
{
    public class Posts
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int authorID { get; set; }
        [Required]
        public string authorName { get; set; }
        [Required(ErrorMessage = "please add post title!")]
        public string postTitile { get; set; }
        [Required(ErrorMessage = "please add post body!")]
        public string postBody { get; set; }

        //To get records of up and soenvotes in order to sort the posts
        [System.ComponentModel.DefaultValue(0)]

        public int likes { get; set; }
        [System.ComponentModel.DefaultValue(0)]

        public int dislikes { get; set; }

        public DateTime? date {get;set;}
    }
}
