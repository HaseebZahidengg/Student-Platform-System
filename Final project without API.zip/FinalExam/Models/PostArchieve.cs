﻿using System.Collections.Generic;

namespace FinalExam.Models
{
    public class PostArchieve
    {
        public List<Posts> AllPosts { get; set; }
        public List<Comments> AllComments { get; set; }
        public List<Votes> AllVotes { get; set; }   
    }
}
