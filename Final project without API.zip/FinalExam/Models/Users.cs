﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace FinalExam.Models
{
    [Index(nameof(Users.username), IsUnique = true)]

    public class Users
    {
        [Key]
        public int Id { get; set; }
        [Required (ErrorMessage ="add first name")]
        public string firstName { get; set; }
        public string lastName { get; set; }
        [Required (ErrorMessage ="add username")]
        public string username { get; set; }
        [Required (ErrorMessage ="add password")]
        public string password { get; set; }
        [Required]
        public bool isSuperUser { get; set; }
        [Required]
        public bool isInstructor { get; set; }
        [Required]
        public bool isStudent { get; set; }

    }
}
