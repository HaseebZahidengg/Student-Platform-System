﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FinalExam.Models
{
    public class Votes
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int postID { get; set; }
        [ForeignKey("postID")]
        public Posts Posts { get; set; }
        [Required]
        public int userID { get; set; }
        [ForeignKey("userID")]
        public Users Users { get; set; }
        public bool status { get; set; }

    }
}
