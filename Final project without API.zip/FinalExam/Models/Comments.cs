﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;


namespace FinalExam.Models
{
    public class Comments
    {
        [Key] 

        public int Id { get; set; }
        [Required]
        public string commentBody { get; set; }
        public int postID { get; set; }
        [ForeignKey("postID")]
        public Posts Posts { get; set; }

        public int authorID { get; set; }
        [ForeignKey("authorID")]
        public Users Users { get; set; }
        public string authername { get; set; }
    }
}
