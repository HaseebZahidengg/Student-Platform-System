insert into Users(firstName, lastName, username, password, isSuperUser, isStudent, isInstructor)
Values('Haseeb', 'Zahid', 'haseeb554','Admin1122', 1,0,0)

insert into Users(firstName, lastName, username, password, isSuperUser, isStudent, isInstructor)
Values('Kamran', 'Akmal', 'kami','Admin1122', 0,1,0),
('Ahmad', 'shahzad', 'actor','Admin1122', 0,1,0)


insert into Users(firstName, lastName, username, password, isSuperUser, isStudent, isInstructor)
Values('Babar', 'Azam', 'boby','Admin1122', 0,0,1),
('Shadab', 'hehe', 'shady','Admin1122', 0,0,1)

