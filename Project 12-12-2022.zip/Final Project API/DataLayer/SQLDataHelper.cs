﻿using Final_Project_API.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Final_Project_API.DataLayer
{
    public class SQLDataHelper : ISQLDataHelper
    {
        string connectionString = "";
        public SQLDataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("ProjectDB");
        }


        public static List<Posts> allPosts = new List<Posts>();
        public List<Posts> AllPosts()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                allPosts.Clear();
                SqlCommand cmd = new SqlCommand("ALLPOSTS");
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Connection = con;
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Posts singlePost = new Posts();
                    singlePost.Id = Convert.ToInt32(sdr["Id"]);
                    singlePost.title = Convert.ToString(sdr["title"]);
                    singlePost.body = Convert.ToString(sdr["body"]);
                    singlePost.likes = Convert.ToInt32(sdr["likes"]);
                    singlePost.dislikes = Convert.ToInt32(sdr["dislikes"]);
                    allPosts.Add(singlePost);
                }
            }
            return allPosts;
        }



        public string AddPost(Posts newPost)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("Addpost");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@body", newPost.body);
                cmd.Parameters.AddWithValue("@title", newPost.title);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Post Successfully Added!!!";

            }
        }

        public string EditPost(Posts newPost)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("EDITPOST");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@Id", newPost.Id);
                cmd.Parameters.AddWithValue("@body", newPost.body);
                cmd.Parameters.AddWithValue("@title", newPost.title);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Post Successfully Edited!!!";

            }
        }

        public string DelPsot(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELPOST");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@Id", id);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Post Successfully Deleted!!!";

            }
        }

        public string AddComment(Comment newCmt)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("ADDCOMMENT");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@postid", newCmt.postID);
                cmd.Parameters.AddWithValue("@body", newCmt.body);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Comment Successfully Added!!!";

            }
        }

        public string EditCmt(Comment newCmt)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("EDITCMT");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@Id", newCmt.Id);
                cmd.Parameters.AddWithValue("@postid", newCmt.postID);
                cmd.Parameters.AddWithValue("@body", newCmt.body);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Comment Successfully Edited!!!";

            }
        }
        public string DelCmt(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("DELCMT");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@Id", id);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Comment Successfully Deleted!!!";

            }
        }

        public string LikePost(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("LIKES");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@Id", id);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Post Liked!!!";

            }
        }

        public string dislikePost(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("DISLIKES");
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@Id", id);

                cmd.ExecuteNonQuery();
                con.Close();

                return "Post DIsliked!!!";

            }
        }
    }
}
