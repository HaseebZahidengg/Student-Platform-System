﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Final_Project_API.BusinessLayer;
using Final_Project_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Final_Project_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class finalproject : ControllerBase

    {
        IPassToCotroller _passToController;
        public finalproject(IPassToCotroller passToController)
        {
            _passToController = passToController;
        }

        [Route("AddComment")]
        [HttpPost]
        public string AddComment(Comment newCmt)
        {
            return _passToController.AddComment(newCmt);
        }
        [Route("EditCmt")]
        [HttpPost]
        public string EditCmt(Comment newCmt)
        {
            return _passToController.EditCmt(newCmt);
        }
        [Route("DelCmt/{id}")]
        [HttpDelete]
        public string DelCmt(int id)
        {
            return _passToController.DelCmt(id);
        }

        [Route("AddPost")]
        [HttpPost]
        public string AddPost(Posts newPost)
        {
            return _passToController.AddPost(newPost);
        }

        [Route("LikePost/{id}")]
        [HttpPost]
        public string LikePost(int id)
        {
            return _passToController.LikePost(id);
        }

        [Route("disikePost/{id}")]
        [HttpPost]
        public string disikePost(int id)
        {
            return _passToController.dislikePost(id);
        }


        //[Authorize(Policy = "PublicSecure")]
        [HttpGet]
        [Route("Allposts")]

        public List<Posts> AllPosts()
        {
            return _passToController.AllPosts();
        }

        [Route("Editpost")]
        [HttpPost]
        public string EditPost(Posts newPost)
        {
            return _passToController.EditPost(newPost);
        }

        [Route("DelPost/{id}")]
        [HttpDelete]
        public string DelPsot(int id)
        {
            return _passToController.DelPsot(id);
        }


    }
}
