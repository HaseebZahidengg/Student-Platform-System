

create table Posts(
	Id int primary key identity(1,1) not null,
	title varchar(255) not null,
	body varchar(max) not null,
	likes int default 0,
	dislikes int default 0
);
drop table Posts;
select * from Posts;
insert into Posts(title, body)
values('My first post','Lorem ipsum lorem ipsum lorem ipsum');




--Procedure to add new posts
Create procedure Addpost @title varchar(255), @body varchar(max)
AS
Begin
	insert into Posts(title, body)
	values(@title,@body);
END
exec Addpost @body = 'Test post body', @title='Test post';
--End procedure

--PROCEDURE TO GET LIST OF ALL THE POSTS
create procedure ALLPOSTS 
AS 
Begin
	select* from Posts
END
exec ALLPOSTS
--END 

--EDIT POST
create procedure EDITPOST @title varchar(255), @body varchar(max), @Id int
AS 
begin 
	update Posts
	set title=@title, body=@body
	where Id=@Id
end

exec EDITPOST @Id = 1, @title = 'changed',@body = 'this too shall pass'
--DELETE POST
create procedure DELPOST @Id int
AS
BEGIN
	delete from Posts
	where Id=@Id
END

--ADD LIKES AND DISLIKES
create procedure LIKES @Id int 
AS 
BEGIN 
	update Posts
	set Likes= Likes+1
	where Id=@Id
END
exec LIKES @Id =1


create procedure DISLIKES @Id int 
AS 
BEGIN 
	update Posts
	set dislikes= dislikes+1
	where Id=@Id
END
exec DISLIKES @Id =1




--COMMENT AREA
create table Comment(
	Id int primary key identity(1,1) not null,
	postID int foreign key references Posts(Id),
	body varchar(max) not null,
);
--END
create procedure ADDCOMMENT @body varchar(max), @postid int
AS
BEGIN
	insert into Comment(postID,body)
	values(@postid, @body)
END
exec ADDCOMMENT @postid = 2, @body='My second comment'
---


--edit comment
create procedure EDITCMT @body varchar(max), @Id int, @postID int
AS 
begin 
	update Comment
	set body=@body, postID=@postID
	where Id=@Id
end
exec EDITCMT @Id=1, @postID=1, @body='changed'
--delete comment
create procedure DELCMT @Id int
AS
BEGIN
	delete from Comment
	where Id=@Id
END

create procedure ALLCOMMENTS
AS 
BEGIN 
	select * from Comment
END
exec ALLCOMMENTS 

