

create table Posts(
	Id int primary key identity(1,1) not null,
	title varchar(255) not null,
	body varchar(max) not null,
	authorID int,
	likes int default 0,
	dislikes int default 0
);



insert into Posts(title, body, authorID)
values('My first post','Lorem ipsum lorem ipsum lorem ipsum', 1);




--Procedure to add new posts
Create procedure Addpost @title varchar(255), @body varchar(max), @authorID int
AS
Begin
	insert into Posts(title, body, authorID)
	values(@title,@body,@authorID);
END

exec Addpost @body = 'for you a thousand time over', @title='the kite runner', @authorID =4;

--End procedure

--PROCEDURE TO GET LIST OF ALL THE POSTS
create procedure ALLPOSTS 
AS 
Begin
	select* from Posts
	order by likes DESC,  Id DESC
END

exec ALLPOSTS
--END 



--EDIT POST
create procedure EDITPOST @title varchar(255), @body varchar(max), @Id int, @author int
AS 
begin 
	update Posts
	set title=@title, body=@body
	where Id=@Id AND authorID = @author
end



--DELETE POST

create procedure DELPOST @Id int, @author int
AS
BEGIN
	delete from Posts
	where Id=@Id AND authorID= @author
END



--COMMENT AREA
create table Comment(
	Id int primary key identity(1,1) not null,
	postID int foreign key references Posts(Id),
	authorID int,
	body varchar(max) not null,
);


--END
create procedure ADDCOMMENT @body varchar(max), @postid int, @author int
AS
BEGIN
	insert into Comment(postID,body, authorID)
	values(@postid, @body, @author)
END

exec ADDCOMMENT @postid = 2, @body='My second comment'
---


--edit comment
create procedure EDITCMT @body varchar(max), @Id int, @postID int,  @user int
AS 
begin 
	update Comment
	set body=@body, postID=@postID
	where Id=@Id AND authorID=@user
end



--delete comment
create procedure DELCMT @Id int, @user int
AS
BEGIN
	delete from Comment
	where Id=@Id AND authorID = @user
END


create procedure ALLCOMMENTS
AS 
BEGIN 
	select * from Comment
END

exec ALLCOMMENTS 




--VOTES AREA
create table Votes(
	Id int primary key identity(1,1) not null,
	userID int,
	postID int foreign key references Posts(Id),
	status BIT,
);

create procedure vote @postId int, @user int, @status BIT
AS 
BEGIN 

	if not exists (select * from Votes where postID = @postId AND userID =@user)
		BEGIN
			insert into Votes(userID, postID, status)
			values(@user, @postId, @status)
			
			if (@status = 1)
			BEGIN
				update Posts
				set likes = likes+1
				where Id=@postId
			END
			ELSE
			BEGIN
				update Posts
				set dislikes = dislikes+1
				where Id=@postId
			END

		END
	else
		BEGIN
			if exists(select * from Votes where postID = @postId AND userID =@user AND status = 0 AND @status=1)
			BEGIN
				update votes 
				set status = @status
				where postID = @postId AND userID =@user;

				update Posts
				set likes = likes+1, dislikes=dislikes-1
				where Id=@postId

			END

			if exists(select * from Votes where postID = @postId AND userID =@user AND status = 1 AND @status=0)
			BEGIN
				update votes 
				set status = @status
				where postID = @postId AND userID =@user;

				update Posts
				set likes = likes-1, dislikes=dislikes+1
				where Id=@postId
			END
		END
END
--drop procedure vote
exec vote @user = 4, @postID =1, @status = 0


select * from votes
select * from posts
delete from votes where userID =3