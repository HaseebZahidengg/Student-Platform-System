﻿using Final_Project_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Project_API.BusinessLayer
{
    public interface IPassToCotroller
    {
        public string AddPost(Posts newPost);
        public List<Posts> AllPosts();
        public string AddComment(Comment newCmt);
        public string EditPost(Posts newPost, int author);
        public string DelPsot(int id, int author);
        public string EditCmt(Comment newCmt, int user);
        public string DelCmt(int id, int user);
        public string LikePost(int id);
        public string dislikePost(int id);
        public string vote(vote thisVote);
    }
}
