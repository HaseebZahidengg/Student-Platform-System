﻿using System.ComponentModel.DataAnnotations;

namespace Final_Project_API.Models
{
    public class vote
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public int postID { get; set; }
        public int userID { get; set; }
        [Required]
        public bool status { get; set; }
    }
}
