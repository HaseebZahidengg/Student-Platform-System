﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Project_API.Models
{
    public class Posts
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [MaxLength(255)]
        public string title { get; set; }

        [Required]
        public string body { get; set; }

        public int likes {get; set;}
        public int dislikes {get; set;}
        public int authorID { get; set; }

    }
}
