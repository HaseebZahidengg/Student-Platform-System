﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Final_Project_API.BusinessLayer;
using Final_Project_API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Final_Project_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class finalproject : ControllerBase

    {
        IPassToCotroller _passToController;
        public finalproject(IPassToCotroller passToController)
        {
            _passToController = passToController;
        }

        [Route("AddPost")]
        [HttpPost]
        public string AddPost(Posts newPost)
        {
            return _passToController.AddPost(newPost);
        }


        [Authorize(Policy = "PublicSecure")]
        [HttpGet]
        [Route("Allposts")]

        public List<Posts> AllPosts()
        {
            return _passToController.AllPosts();
        }

        [Route("AddComment")]
        [HttpPost]
        public string AddComment(Comment newCmt)
        {
            return _passToController.AddComment(newCmt);
        }
    }
}
