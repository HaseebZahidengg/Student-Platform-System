

create table Posts(
	Id int primary key identity(1,1) not null,
	title varchar(255) not null,
	body varchar(max) not null,
	likes int default 0,
	dislikes int default 0
);
drop table Posts;
select * from Posts;
insert into Posts(title, body)
values('My first post','Lorem ipsum lorem ipsum lorem ipsum');




--Provedure to add new book
Create procedure Addpost @title varchar(255), @body varchar(max)
AS
Begin
	insert into Posts(title, body)
	values(@title,@body);
END
exec Addpost @body = 'Test post body', @title='Test post';
--End procedure

--PROCEDURE TO GET LIST OF ALL THE POSTS
create procedure ALLPOSTS 
AS 
Begin
	select* from Posts
END
exec ALLPOSTS
--END 


--COMMENT AREA
create table Comment(
	Id int primary key identity(1,1) not null,
	postID int foreign key references Posts(Id),
	body varchar(max) not null,
);
--END
create procedure ADDCOMMENT @body varchar(max), @postid int
AS
BEGIN
	insert into Comment(postID,body)
	values(@postid, @body)
END
exec ADDCOMMENT @postid = 1, @body='My first comment'
---

create procedure ALLCOMMENTS
AS 
BEGIN 
	select * from Comment
END
exec ALLCOMMENTS 
