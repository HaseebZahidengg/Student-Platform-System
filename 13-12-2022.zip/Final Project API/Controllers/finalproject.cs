﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Final_Project_API.BusinessLayer;
using Final_Project_API.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Final_Project_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class finalproject : ControllerBase

    {
        IPassToCotroller _passToController;
        public finalproject(IPassToCotroller passToController)
        {
            _passToController = passToController;
        }


        [Authorize(Policy = "LoggedIn")]
        [Route("AddComment")]
        [HttpPost]
        public string AddComment(Comment newCmt)
        {
            int user = Convert.ToInt32(User.Claims.ToList()[5].Value);
            newCmt.authorID = user;
            return _passToController.AddComment(newCmt);
        }

        [Authorize(Policy = "LoggedIn")]
        [Route("EditCmt")]
        [HttpPost]
        public string EditCmt(Comment newCmt)
        {
            int user = Convert.ToInt32(User.Claims.ToList()[5].Value);
            return _passToController.EditCmt(newCmt, user);
        }

        [Authorize(Policy = "LoggedIn")]
        [Route("DelCmt/{id}")]
        [HttpDelete]
        public string DelCmt(int id)
        {
            int user = Convert.ToInt32(User.Claims.ToList()[5].Value);
            return _passToController.DelCmt(id, user);
        }




        [Route("LikePost/{id}")]
        [HttpPost]
        public string LikePost(int id)
        {
            return _passToController.LikePost(id);
        }

        [Route("disikePost/{id}")]
        [HttpPost]
        public string disikePost(int id)
        {
            return _passToController.dislikePost(id);
        }




        [Authorize(Policy = "PublicSecure")]
        [HttpGet]
        [Route("Allposts")]

        public List<Posts> AllPosts()
        {
            return _passToController.AllPosts();
        }


        [Authorize(Policy = "InstructorsOnly")]
        [Route("AddPost")]
        [HttpPost]
        public string AddPost(Posts newPost)
        {
            int test = Convert.ToInt32(User.Claims.ToList()[5].Value);

            newPost.authorID = test;

            return _passToController.AddPost(newPost);
        }

        [Authorize(Policy = "InstructorsOnly")]
        [Route("Editpost")]
        [HttpPost]
        public string EditPost(Posts newPost)
        {
            int author = Convert.ToInt32(User.Claims.ToList()[5].Value);
            return _passToController.EditPost(newPost, author);
        }

        [Authorize(Policy = "InstructorsOnly")]
        [Route("DelPost/{id}")]
        [HttpDelete]
        public string DelPsot(int id)
        {
            int author = Convert.ToInt32(User.Claims.ToList()[5].Value);
            return _passToController.DelPsot(id,author);
        }


    }
}
