﻿using Final_Project_API.DataLayer;
using Final_Project_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Project_API.BusinessLayer
{
    public class PassToCotroller: IPassToCotroller
    {
        ISQLDataHelper _sqlDataHelper;
        public PassToCotroller(ISQLDataHelper sqlDataHelper)
        {
            this._sqlDataHelper = sqlDataHelper;
        }

        public string AddPost(Posts newPost)
        {
            return this._sqlDataHelper.AddPost(newPost);
        }
        public List<Posts> AllPosts()
        {
            return this._sqlDataHelper.AllPosts();
        }
        public string AddComment(Comment newCmt)
        {
            return this._sqlDataHelper.AddComment(newCmt);
        }
        public string EditPost(Posts newPost, int author)
        {
            return this._sqlDataHelper.EditPost(newPost , author);
        }
        public string DelPsot(int id, int author)
        {
            return this._sqlDataHelper.DelPsot(id, author);
        }
        public string EditCmt(Comment newCmt, int user)
        {
            return this._sqlDataHelper.EditCmt(newCmt, user);
        }
        public string DelCmt(int id, int user)
        {
            return this._sqlDataHelper.DelCmt(id, user);
        }
        public string LikePost(int id)
        {
            return this._sqlDataHelper.LikePost(id);
        }
        public string dislikePost(int id)
        {
            return this._sqlDataHelper.dislikePost(id);
        }
    }
}
