﻿using Final_Project_API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Final_Project_API.BusinessLayer
{
    public interface IPassToCotroller
    {
        public string AddPost(Posts newPost);
        public List<Posts> AllPosts();
        public string AddComment(Comment newCmt);
    }
}
